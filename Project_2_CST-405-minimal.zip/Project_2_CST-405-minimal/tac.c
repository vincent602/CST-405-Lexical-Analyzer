#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "tac.h"

TACList tacList;
TACList optimizedList;

void initTAC() {
    tacList.head = NULL;
    tacList.tail = NULL;
    tacList.tempCount = 0;
    optimizedList.head = NULL;
    optimizedList.tail = NULL;
}

char* newTemp() {
    char* temp = malloc(10);
    sprintf(temp, "t%d", tacList.tempCount++);
    return temp;
}

TACInstr* createTAC(TACOp op, char* arg1, char* arg2, char* result) {
    TACInstr* instr = malloc(sizeof(TACInstr));
    instr->op = op;
    instr->arg1 = arg1 ? strdup(arg1) : NULL;
    instr->arg2 = arg2 ? strdup(arg2) : NULL;
    instr->result = result ? strdup(result) : NULL;
    instr->next = NULL;
    return instr;
}

void appendTAC(TACInstr* instr) {
    if (!tacList.head) {
        tacList.head = tacList.tail = instr;
    } else {
        tacList.tail->next = instr;
        tacList.tail = instr;
    }
}

void appendOptimizedTAC(TACInstr* instr) {
    if (!optimizedList.head) {
        optimizedList.head = optimizedList.tail = instr;
    } else {
        optimizedList.tail->next = instr;
        optimizedList.tail = instr;
    }
}

char* generateTACExpr(ASTNode* node) {
    if (!node) return NULL;
    
    switch(node->type) {
        case NODE_NUM: {
            char* temp = malloc(20);
            sprintf(temp, "%d", node->data.num);
            return temp;
        }
        
        case NODE_VAR:
            return strdup(node->data.name);
        
        case NODE_BINOP: {
            char* left = generateTACExpr(node->data.binop.left);
            char* right = generateTACExpr(node->data.binop.right);
            char* temp = newTemp();
            
            if (node->data.binop.op == '+') {
                appendTAC(createTAC(TAC_ADD, left, right, temp));
            }
            
            return temp;
        }
        
        default:
            return NULL;
    }
}

void generateTAC(ASTNode* node) {
    if (!node) return;
    
    switch(node->type) {
        case NODE_DECL:
            appendTAC(createTAC(TAC_DECL, NULL, NULL, node->data.name));
            break;
            
        case NODE_ASSIGN: {
            char* expr = generateTACExpr(node->data.assign.value);
            appendTAC(createTAC(TAC_ASSIGN, expr, NULL, node->data.assign.var));
            break;
        }
        
        case NODE_PRINT: {
            char* expr = generateTACExpr(node->data.expr);
            appendTAC(createTAC(TAC_PRINT, expr, NULL, NULL));
            break;
        }
        
        case NODE_STMT_LIST:
            generateTAC(node->data.stmtlist.stmt);
            generateTAC(node->data.stmtlist.next);
            break;
            
        default:
            break;
    }
}

void printTAC() {
    printf("Unoptimized TAC Instructions:\n");
    printf("─────────────────────────────\n");
    TACInstr* curr = tacList.head;
    int lineNum = 1;
    while (curr) {
        printf("%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                printf("DECL %s", curr->result);
                printf("          // Declare variable '%s'\n", curr->result);
                break;
            case TAC_ADD:
                printf("%s = %s + %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Add: store result in %s\n", curr->result);
                break;
            case TAC_ASSIGN:
                printf("%s = %s", curr->result, curr->arg1);
                printf("           // Assign value to %s\n", curr->result);
                break;
            case TAC_PRINT:
                printf("PRINT %s", curr->arg1);
                printf("          // Output value of %s\n", curr->arg1);
                break;
            default:
                break;
        }
        curr = curr->next;
    }
}

/* ================================================================
 * ENHANCED OPTIMIZATION ENGINE
 * ================================================================ */

/* Helper: Check if a string is a constant (all digits) */
int isConstant(const char* str) {
    if (!str || str[0] == '\0') return 0;
    for (int i = 0; str[i]; i++) {
        if (!isdigit(str[i]) && str[i] != '-') return 0;
    }
    return 1;
}

/* Helper: Check if a variable is a temporary (starts with 't') */
int isTemp(const char* str) {
    return str && str[0] == 't' && isdigit(str[1]);
}

/* LIVENESS ANALYSIS - Find which variables are "live" (used later)
 * A variable is live if its value is needed in a future instruction */
typedef struct LivenessInfo {
    char* var;                    /* Variable name */
    int isLive;                   /* 1 if live, 0 if dead */
    struct LivenessInfo* next;
} LivenessInfo;

LivenessInfo* livenessTable = NULL;

void markAsLive(const char* var) {
    if (!var) return;
    
    /* Check if already in table */
    LivenessInfo* curr = livenessTable;
    while (curr) {
        if (strcmp(curr->var, var) == 0) {
            curr->isLive = 1;
            return;
        }
        curr = curr->next;
    }
    
    /* Add new entry */
    LivenessInfo* info = malloc(sizeof(LivenessInfo));
    info->var = strdup(var);
    info->isLive = 1;
    info->next = livenessTable;
    livenessTable = info;
}

int isLive(const char* var) {
    if (!var) return 0;
    
    LivenessInfo* curr = livenessTable;
    while (curr) {
        if (strcmp(curr->var, var) == 0) {
            return curr->isLive;
        }
        curr = curr->next;
    }
    return 0;  /* Not in table = dead */
}

/* Perform backward liveness analysis */
void analyzeLiveness() {
    /* Free old liveness info */
    while (livenessTable) {
        LivenessInfo* temp = livenessTable;
        livenessTable = livenessTable->next;
        free(temp->var);
        free(temp);
    }
    livenessTable = NULL;
    
    /* Pass 1: Scan backwards to find all used variables */
    TACInstr* curr = tacList.head;
    
    /* Count instructions first */
    int count = 0;
    while (curr) {
        count++;
        curr = curr->next;
    }
    
    /* Store instructions in array for backward scan */
    TACInstr** instructions = malloc(count * sizeof(TACInstr*));
    curr = tacList.head;
    for (int i = 0; i < count; i++) {
        instructions[i] = curr;
        curr = curr->next;
    }
    
    /* Scan backwards */
    for (int i = count - 1; i >= 0; i--) {
        TACInstr* instr = instructions[i];
        
        switch(instr->op) {
            case TAC_PRINT:
                /* Variable used in print is live */
                markAsLive(instr->arg1);
                break;
                
            case TAC_ASSIGN:
                /* If result is live, then arg1 must be live */
                if (isLive(instr->result)) {
                    markAsLive(instr->arg1);
                }
                break;
                
            case TAC_ADD:
                /* If result is live, both operands must be live */
                if (isLive(instr->result)) {
                    markAsLive(instr->arg1);
                    markAsLive(instr->arg2);
                }
                break;
                
            default:
                break;
        }
    }
    
    free(instructions);
    
    printf("\n=== LIVENESS ANALYSIS ===\n");
    LivenessInfo* info = livenessTable;
    while (info) {
        printf("  %s: %s\n", info->var, info->isLive ? "LIVE" : "DEAD");
        info = info->next;
    }
    printf("=========================\n\n");
}

/* Enhanced optimization with multiple passes */
void optimizeTAC() {
    printf("\n=== OPTIMIZATION PASSES ===\n");
    
    /* PASS 1: Liveness Analysis */
    printf("Pass 1: Liveness Analysis\n");
    analyzeLiveness();
    
    /* Value propagation table */
    typedef struct {
        char* var;
        char* value;
    } VarValue;
    
    VarValue values[100];
    int valueCount = 0;
    
    int deadCodeEliminated = 0;
    int constantsFolded = 0;
    int copiesPropagated = 0;
    
    /* PASS 2: Dead Code Elimination, Constant Folding, Copy Propagation */
    printf("Pass 2: Optimization Transformations\n");
    
    TACInstr* curr = tacList.head;
    
    while (curr) {
        TACInstr* newInstr = NULL;
        int shouldEmit = 1;  /* Should we emit this instruction? */
        
        switch(curr->op) {
            case TAC_DECL:
                /* Always emit declarations */
                newInstr = createTAC(TAC_DECL, NULL, NULL, curr->result);
                break;
                
            case TAC_ADD: {
                /* DEAD CODE ELIMINATION: Skip if result is never used */
                if (!isLive(curr->result)) {
                    printf("  → ELIMINATED: %s = %s + %s (dead code)\n", 
                           curr->result, curr->arg1, curr->arg2);
                    shouldEmit = 0;
                    deadCodeEliminated++;
                    break;
                }
                
                /* COPY PROPAGATION: Replace variables with their known values */
                char* left = curr->arg1;
                char* right = curr->arg2;
                
                /* Look up values in propagation table */
                for (int i = valueCount - 1; i >= 0; i--) {
                    if (strcmp(values[i].var, left) == 0) {
                        left = values[i].value;
                        copiesPropagated++;
                        break;
                    }
                }
                for (int i = valueCount - 1; i >= 0; i--) {
                    if (strcmp(values[i].var, right) == 0) {
                        right = values[i].value;
                        copiesPropagated++;
                        break;
                    }
                }
                
                /* CONSTANT FOLDING: Evaluate at compile time if both are constants */
                if (isConstant(left) && isConstant(right)) {
                    int result = atoi(left) + atoi(right);
                    char* resultStr = malloc(20);
                    sprintf(resultStr, "%d", result);
                    
                    printf("  → FOLDED: %s + %s = %d\n", left, right, result);
                    constantsFolded++;
                    
                    /* Store for propagation */
                    values[valueCount].var = strdup(curr->result);
                    values[valueCount].value = resultStr;
                    valueCount++;
                    
                    newInstr = createTAC(TAC_ASSIGN, resultStr, NULL, curr->result);
                } else {
                    newInstr = createTAC(TAC_ADD, left, right, curr->result);
                }
                break;
            }
            
            case TAC_ASSIGN: {
                /* DEAD CODE ELIMINATION: Skip if result is never used */
                if (!isLive(curr->result) && isTemp(curr->result)) {
                    printf("  → ELIMINATED: %s = %s (dead code)\n", 
                           curr->result, curr->arg1);
                    shouldEmit = 0;
                    deadCodeEliminated++;
                    break;
                }
                
                /* COPY PROPAGATION: Replace variable with its known value */
                char* value = curr->arg1;
                
                for (int i = valueCount - 1; i >= 0; i--) {
                    if (strcmp(values[i].var, value) == 0) {
                        value = values[i].value;
                        copiesPropagated++;
                        break;
                    }
                }
                
                /* Store for future propagation */
                values[valueCount].var = strdup(curr->result);
                values[valueCount].value = strdup(value);
                valueCount++;
                
                newInstr = createTAC(TAC_ASSIGN, value, NULL, curr->result);
                break;
            }
            
            case TAC_PRINT: {
                /* COPY PROPAGATION: Replace variable with its known value */
                char* value = curr->arg1;
                
                for (int i = valueCount - 1; i >= 0; i--) {
                    if (strcmp(values[i].var, value) == 0) {
                        value = values[i].value;
                        copiesPropagated++;
                        break;
                    }
                }
                
                newInstr = createTAC(TAC_PRINT, value, NULL, NULL);
                break;
            }
        }
        
        if (shouldEmit && newInstr) {
            appendOptimizedTAC(newInstr);
        }
        
        curr = curr->next;
    }
    
    printf("\n=== OPTIMIZATION SUMMARY ===\n");
    printf("  Dead code eliminated: %d instruction(s)\n", deadCodeEliminated);
    printf("  Constants folded: %d operation(s)\n", constantsFolded);
    printf("  Copies propagated: %d substitution(s)\n", copiesPropagated);
    printf("============================\n\n");
}

void printOptimizedTAC() {
    printf("Optimized TAC Instructions:\n");
    printf("─────────────────────────────\n");
    TACInstr* curr = optimizedList.head;
    int lineNum = 1;
    while (curr) {
        printf("%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                printf("DECL %s\n", curr->result);
                break;
            case TAC_ADD:
                printf("%s = %s + %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Runtime addition needed\n");
                break;
            case TAC_ASSIGN:
                printf("%s = %s", curr->result, curr->arg1);
                if (isConstant(curr->arg1)) {
                    printf("           // Constant value: %s\n", curr->arg1);
                } else {
                    printf("           // Copy value\n");
                }
                break;
            case TAC_PRINT:
                printf("PRINT %s", curr->arg1);
                if (isConstant(curr->arg1)) {
                    printf("          // Print constant: %s\n", curr->arg1);
                } else {
                    printf("          // Print variable\n");
                }
                break;
            default:
                break;
        }
        curr = curr->next;
    }
}

void saveTACToFile(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot open file '%s' for writing\n", filename);
        return;
    }

    fprintf(file, "# Three-Address Code (TAC) - Unoptimized\n");
    fprintf(file, "# Generated by Minimal C Compiler\n");
    fprintf(file, "# ─────────────────────────────────────\n\n");

    TACInstr* curr = tacList.head;
    int lineNum = 1;
    while (curr) {
        fprintf(file, "%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                fprintf(file, "DECL %s\n", curr->result);
                break;
            case TAC_ADD:
                fprintf(file, "%s = %s + %s\n", curr->result, curr->arg1, curr->arg2);
                break;
            case TAC_ASSIGN:
                fprintf(file, "%s = %s\n", curr->result, curr->arg1);
                break;
            case TAC_PRINT:
                fprintf(file, "PRINT %s\n", curr->arg1);
                break;
            default:
                break;
        }
        curr = curr->next;
    }

    fclose(file);
}

void saveOptimizedTACToFile(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot open file '%s' for writing\n", filename);
        return;
    }

    fprintf(file, "# Three-Address Code (TAC) - Optimized\n");
    fprintf(file, "# Generated by Minimal C Compiler\n");
    fprintf(file, "# Optimizations applied:\n");
    fprintf(file, "#   - Dead code elimination\n");
    fprintf(file, "#   - Constant folding\n");
    fprintf(file, "#   - Copy propagation\n");
    fprintf(file, "# ─────────────────────────────────────\n\n");

    TACInstr* curr = optimizedList.head;
    int lineNum = 1;
    while (curr) {
        fprintf(file, "%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                fprintf(file, "DECL %s\n", curr->result);
                break;
            case TAC_ADD:
                fprintf(file, "%s = %s + %s\n", curr->result, curr->arg1, curr->arg2);
                break;
            case TAC_ASSIGN:
                fprintf(file, "%s = %s\n", curr->result, curr->arg1);
                break;
            case TAC_PRINT:
                fprintf(file, "PRINT %s\n", curr->arg1);
                break;
            default:
                break;
        }
        curr = curr->next;
    }

    fclose(file);
}