#ifndef AST_H
#define AST_H

/* ABSTRACT SYNTAX TREE (AST)
 * The AST is an intermediate representation of the program structure
 * It represents the hierarchical syntax of the source code
 * Each node represents a construct in the language
 */

/* PARAMETER LIST STRUCTURE for function parameters */
typedef struct ParamList {
    char* type;                 /* Parameter type (int, float, etc.) */
    char* name;                 /* Parameter name */
    struct ParamList* next;     /* Next parameter in list */
} ParamList;

/* NODE TYPES - Different kinds of AST nodes in our language */
typedef enum {
    NODE_NUM,       /* Numeric literal (e.g., 42) */
    NODE_VAR,       /* Variable reference (e.g., x) */
    NODE_BINOP,     /* Binary operation (e.g., x + y) */
    NODE_DECL,      /* Variable declaration (e.g., int x) - OLD STYLE */
    NODE_ASSIGN,    /* Assignment statement (e.g., x = 10) */
    NODE_PRINT,     /* Print statement (e.g., print(x)) */
    NODE_STMT_LIST, /* List of statements (program structure) */
    /* NEW: Function-related nodes */
    NODE_FUNCTION,      /* Function definition */
    NODE_FUNCTION_LIST, /* List of functions */
    NODE_FUNCTION_CALL, /* Function call */
    NODE_RETURN,        /* Return statement */
    NODE_BLOCK,         /* Code block { } */
    NODE_ARG_LIST,      /* Function call arguments */
    NODE_TYPED_DECL     /* Variable declaration with type */
} NodeType;

/* AST NODE STRUCTURE
 * Uses a union to efficiently store different node data
 * Only the relevant fields for each node type are used
 */
typedef struct ASTNode {
    NodeType type;  /* Identifies what kind of node this is */
    
    /* Union allows same memory to store different data types */
    union {
        /* Literal number value (NODE_NUM) */
        int num;
        
        /* Variable or declaration name (NODE_VAR, NODE_DECL) */
        char* name;
        /* int value; */ /* For potential future use in declarations with assignment */

        
        /* Binary operation structure (NODE_BINOP) */
        struct {
            char op;                    /* Operator character ('+') */
            struct ASTNode* left;       /* Left operand */
            struct ASTNode* right;      /* Right operand */
        } binop;
        
        /* Assignment structure (NODE_ASSIGN) */
        struct {
            char* var;                  /* Variable being assigned to */
            struct ASTNode* value;      /* Expression being assigned */
        } assign;
        
        /* Print expression (NODE_PRINT) */
        struct ASTNode* expr;
        
        /* Statement list structure (NODE_STMT_LIST) */
        struct {
            struct ASTNode* stmt;       /* Current statement */
            struct ASTNode* next;       /* Rest of the list */
        } stmtlist;
        
        /* NEW: Function definition (NODE_FUNCTION) */
        struct {
            char* returnType;           /* Return type: int, void, etc. */
            char* name;                 /* Function name */
            ParamList* params;          /* Parameter list (NULL if no params) */
            struct ASTNode* body;       /* Function body (block) */
        } function;
        
        /* NEW: Function list (NODE_FUNCTION_LIST) */
        struct {
            struct ASTNode* function;
            struct ASTNode* next;
        } functionlist;
        
        /* NEW: Function call (NODE_FUNCTION_CALL) */
        struct {
            char* name;                 /* Function name */
            struct ASTNode* args;       /* Argument list (NULL if no args) */
        } functioncall;
        
        /* NEW: Return statement (NODE_RETURN) */
        struct ASTNode* returnExpr;     /* Expression to return (NULL for void) */
        
        /* NEW: Code block (NODE_BLOCK) */
        struct ASTNode* blockStmts;     /* Statements inside block */
        
        /* NEW: Argument list (NODE_ARG_LIST) */
        struct {
            struct ASTNode* expr;       /* Current argument expression */
            struct ASTNode* next;       /* Next argument */
        } arglist;
        
        /* NEW: Typed declaration (NODE_TYPED_DECL) */
        struct {
            char* varType;              /* Variable type */
            char* varName;              /* Variable name */
        } typedDecl;
    } data;
} ASTNode;

/* AST CONSTRUCTION FUNCTIONS
 * These functions are called by the parser to build the tree
 */
ASTNode* createNum(int value);                                   /* Create number node */
ASTNode* createVar(char* name);                                  /* Create variable node */
ASTNode* createBinOp(char op, ASTNode* left, ASTNode* right);   /* Create binary op node */
ASTNode* createDecl(char* name);                                /* Create declaration node */
ASTNode* createAssign(char* var, ASTNode* value);               /* Create assignment node */
ASTNode* createPrint(ASTNode* expr);                            /* Create print node */
ASTNode* createStmtList(ASTNode* stmt1, ASTNode* stmt2);        /* Create statement list */

/* NEW: Function-related construction functions */
ASTNode* createFunction(char* returnType, char* name, ParamList* params, ASTNode* body);
ASTNode* createFunctionList(ASTNode* func1, ASTNode* func2);
ASTNode* createFunctionCall(char* name, ASTNode* args);
ASTNode* createArgList(ASTNode* expr, ASTNode* next);
ASTNode* createReturn(ASTNode* expr);
ASTNode* createBlock(ASTNode* stmts);
ParamList* createParam(char* type, char* name);
ParamList* addParam(ParamList* list, char* type, char* name);
ASTNode* createTypedDecl(char* type, char* name);

/* AST DISPLAY FUNCTION */
void printAST(ASTNode* node, int level);                        /* Pretty-print the AST */
void printParams(ParamList* params);                            /* Print parameter list */

#endif