/* SEMANTIC ANALYZER IMPLEMENTATION
 * Checks the AST for semantic errors before code generation
 * This ensures the program makes sense semantically, even if syntactically correct
 * NOW WITH TYPE CHECKING!
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantic.h"
#include "symtab.h"

/* Track number of semantic errors found */
int semanticErrors = 0;

/* Initialize semantic analyzer */
void initSemantic() {
    semanticErrors = 0;
    printf("SEMANTIC ANALYZER: Initialized\n\n");
}

/* Report a semantic error */
void reportSemanticError(const char* msg) {
    printf("✗ SEMANTIC ERROR: %s\n", msg);
    semanticErrors++;
}

/* INFER THE TYPE OF AN EXPRESSION
 * Returns the type that an expression evaluates to.
 */
VarType inferExprType(ASTNode* node) {
    if (!node) return TYPE_UNKNOWN;

    switch(node->type) {
        case NODE_NUM:
            /* Integer literals have type INT */
            printf("  → Expression is integer literal (type: int)\n");
            return TYPE_INT;

        case NODE_VAR: {
            /* Variable's type comes from symbol table */
            if (!isVarDeclared(node->data.name)) {
                /* This error is caught elsewhere, but return UNKNOWN */
                return TYPE_UNKNOWN;
            }
            VarType varType = getVarType(node->data.name);
            printf("  → Variable '%s' has type: %s\n", 
                   node->data.name, typeToString(varType));
            return varType;
        }

        case NODE_BINOP: {
            /* For binary operations, check both operands */
            printf("  → Analyzing binary operation operands:\n");
            VarType leftType = inferExprType(node->data.binop.left);
            VarType rightType = inferExprType(node->data.binop.right);
            
            /* Both operands should have the same type */
            if (leftType != rightType && 
                leftType != TYPE_UNKNOWN && 
                rightType != TYPE_UNKNOWN) {
                char errorMsg[256];
                sprintf(errorMsg, "Type mismatch in binary operation: %s %c %s",
                        typeToString(leftType),
                        node->data.binop.op,
                        typeToString(rightType));
                reportSemanticError(errorMsg);
                return TYPE_UNKNOWN;
            }
            
            /* Result type is the same as operands (for now) */
            printf("  → Binary operation result type: %s\n", 
                   typeToString(leftType));
            return leftType;
        }

        default:
            return TYPE_UNKNOWN;
    }
}

/* Analyze an expression for semantic correctness */
void analyzeExpr(ASTNode* node) {
    if (!node) return;

    switch(node->type) {
        case NODE_NUM:
            /* Numbers are always valid */
            break;

        case NODE_VAR: {
            /* Check if variable has been declared */
            if (!isVarDeclared(node->data.name)) {
                char errorMsg[256];
                sprintf(errorMsg, "Variable '%s' used before declaration", node->data.name);
                reportSemanticError(errorMsg);
            } else {
                printf("  ✓ Variable '%s' is declared\n", node->data.name);
            }
            break;
        }

        case NODE_BINOP:
            /* Recursively analyze both operands */
            analyzeExpr(node->data.binop.left);
            analyzeExpr(node->data.binop.right);
            break;

        default:
            break;
    }
}

/* Analyze a statement for semantic correctness */
void analyzeStmt(ASTNode* node) {
    if (!node) return;

    switch(node->type) {
        case NODE_DECL: {
            /* Check if variable is already declared */
            if (isVarDeclared(node->data.name)) {
                char errorMsg[256];
                sprintf(errorMsg, "Variable '%s' already declared", node->data.name);
                reportSemanticError(errorMsg);
            } else {
                /* SINCE YOUR PARSER ONLY HANDLES "int" FOR NOW,
                 * We always declare variables as TYPE_INT
                 * When you add float/char support to your parser,
                 * you'll need to modify your AST to store the type
                 * and pass it here instead of hardcoding TYPE_INT */
                
                VarType declaredType = TYPE_INT;  /* All declarations are int for now */
                
                /* Add variable to symbol table WITH TYPE */
                int offset = addVar(node->data.name, declaredType);
                if (offset != -1) {
                    printf("  ✓ Variable '%s' (type: %s) declared successfully\n", 
                           node->data.name, typeToString(declaredType));
                }
            }
            break;
        }

        case NODE_ASSIGN: {
            /* STEP 1: Check if variable being assigned to has been declared */
            if (!isVarDeclared(node->data.assign.var)) {
                char errorMsg[256];
                sprintf(errorMsg, "Cannot assign to undeclared variable '%s'", 
                        node->data.assign.var);
                reportSemanticError(errorMsg);
            } else {
                printf("  ✓ Assignment to declared variable '%s'\n", 
                       node->data.assign.var);
                
                /* STEP 2: TYPE CHECKING - This is the new part! */
                printf("  → Checking type compatibility for assignment:\n");
                
                /* Get the type of the variable being assigned to */
                VarType varType = getVarType(node->data.assign.var);
                
                /* Infer the type of the expression being assigned */
                VarType exprType = inferExprType(node->data.assign.value);
                
                /* Check if types match */
                if (varType != exprType && exprType != TYPE_UNKNOWN) {
                    char errorMsg[256];
                    sprintf(errorMsg, 
                            "Type mismatch: Cannot assign %s to variable '%s' of type %s",
                            typeToString(exprType),
                            node->data.assign.var,
                            typeToString(varType));
                    reportSemanticError(errorMsg);
                } else if (exprType != TYPE_UNKNOWN) {
                    printf("  ✓ Type check passed: %s = %s\n",
                           typeToString(varType), typeToString(exprType));
                }
            }
            
            /* Also check the expression for other semantic errors */
            analyzeExpr(node->data.assign.value);
            break;
        }

        case NODE_PRINT:
            /* Check the expression being printed */
            printf("  → Checking print statement expression:\n");
            analyzeExpr(node->data.expr);
            /* Infer and report the type being printed */
            VarType printType = inferExprType(node->data.expr);
            printf("  → Printing expression of type: %s\n", typeToString(printType));
            break;

        case NODE_STMT_LIST:
            /* Recursively analyze all statements */
            analyzeStmt(node->data.stmtlist.stmt);
            analyzeStmt(node->data.stmtlist.next);
            break;

        default:
            break;
    }
}

/* Analyze the entire program */
int analyzeProgram(ASTNode* root) {
    printf("Starting semantic analysis...\n");
    printf("───────────────────────────────\n");

    /* Initialize symbol table for semantic checking */
    initSymTab();

    /* Analyze all statements */
    analyzeStmt(root);

    printf("───────────────────────────────\n");

    /* Report results */
    if (semanticErrors == 0) {
        printf("✓ Semantic analysis passed - no errors found!\n");
        return 1;  /* Success */
    } else {
        printf("✗ Semantic analysis failed with %d error(s)\n", semanticErrors);
        return 0;  /* Failure */
    }
}