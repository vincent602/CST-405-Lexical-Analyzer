/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser.y"

/* SYNTAX ANALYZER (PARSER)
 * This is the second phase of compilation - checking grammar rules
 * Bison generates a parser that builds an Abstract Syntax Tree (AST)
 * The parser uses tokens from the scanner to verify syntax is correct
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

/* External declarations for lexer interface */
extern int yylex();      /* Get next token from scanner */
extern int yyparse();    /* Parse the entire input */
extern FILE* yyin;       /* Input file handle */

void yyerror(const char* s);  /* Error handling function */
ASTNode* root = NULL;          /* Root of the Abstract Syntax Tree */

#line 91 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_NUM = 3,                        /* NUM  */
  YYSYMBOL_FNUM = 4,                       /* FNUM  */
  YYSYMBOL_ID = 5,                         /* ID  */
  YYSYMBOL_INT = 6,                        /* INT  */
  YYSYMBOL_VOID = 7,                       /* VOID  */
  YYSYMBOL_FLOAT = 8,                      /* FLOAT  */
  YYSYMBOL_CHAR = 9,                       /* CHAR  */
  YYSYMBOL_PRINT = 10,                     /* PRINT  */
  YYSYMBOL_PRINTI = 11,                    /* PRINTI  */
  YYSYMBOL_PRINTC = 12,                    /* PRINTC  */
  YYSYMBOL_RETURN = 13,                    /* RETURN  */
  YYSYMBOL_WHILE = 14,                     /* WHILE  */
  YYSYMBOL_FOR = 15,                       /* FOR  */
  YYSYMBOL_LE = 16,                        /* LE  */
  YYSYMBOL_GE = 17,                        /* GE  */
  YYSYMBOL_EQ = 18,                        /* EQ  */
  YYSYMBOL_NE = 19,                        /* NE  */
  YYSYMBOL_20_ = 20,                       /* '<'  */
  YYSYMBOL_21_ = 21,                       /* '>'  */
  YYSYMBOL_22_ = 22,                       /* '+'  */
  YYSYMBOL_23_ = 23,                       /* '-'  */
  YYSYMBOL_24_ = 24,                       /* '*'  */
  YYSYMBOL_25_ = 25,                       /* '/'  */
  YYSYMBOL_26_ = 26,                       /* '('  */
  YYSYMBOL_27_ = 27,                       /* ')'  */
  YYSYMBOL_28_ = 28,                       /* ','  */
  YYSYMBOL_29_ = 29,                       /* '['  */
  YYSYMBOL_30_ = 30,                       /* ']'  */
  YYSYMBOL_31_ = 31,                       /* ';'  */
  YYSYMBOL_32_ = 32,                       /* '='  */
  YYSYMBOL_33_ = 33,                       /* '{'  */
  YYSYMBOL_34_ = 34,                       /* '}'  */
  YYSYMBOL_YYACCEPT = 35,                  /* $accept  */
  YYSYMBOL_program = 36,                   /* program  */
  YYSYMBOL_function_list = 37,             /* function_list  */
  YYSYMBOL_function = 38,                  /* function  */
  YYSYMBOL_params_opt = 39,                /* params_opt  */
  YYSYMBOL_params = 40,                    /* params  */
  YYSYMBOL_param = 41,                     /* param  */
  YYSYMBOL_type_spec = 42,                 /* type_spec  */
  YYSYMBOL_stmt_list = 43,                 /* stmt_list  */
  YYSYMBOL_stmt = 44,                      /* stmt  */
  YYSYMBOL_decl = 45,                      /* decl  */
  YYSYMBOL_assign = 46,                    /* assign  */
  YYSYMBOL_assign_expr = 47,               /* assign_expr  */
  YYSYMBOL_assign_expr_opt = 48,           /* assign_expr_opt  */
  YYSYMBOL_expr_opt = 49,                  /* expr_opt  */
  YYSYMBOL_expr = 50,                      /* expr  */
  YYSYMBOL_while_stmt = 51,                /* while_stmt  */
  YYSYMBOL_for_stmt = 52,                  /* for_stmt  */
  YYSYMBOL_print_stmt = 53,                /* print_stmt  */
  YYSYMBOL_return_stmt = 54,               /* return_stmt  */
  YYSYMBOL_func_call = 55,                 /* func_call  */
  YYSYMBOL_arg_list_opt = 56,              /* arg_list_opt  */
  YYSYMBOL_arg_list = 57,                  /* arg_list  */
  YYSYMBOL_block = 58                      /* block  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  40
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   301

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  35
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  24
/* YYNRULES -- Number of rules.  */
#define YYNRULES  65
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  138

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   274


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      26,    27,    24,    22,    28,    23,     2,    25,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,    31,
      20,    32,    21,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    29,     2,    30,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    33,     2,    34,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    64,    64,    67,    73,    76,    82,    90,    93,    99,
     102,   109,   114,   122,   123,   124,   125,   130,   134,   142,
     143,   144,   145,   146,   147,   148,   153,   158,   167,   172,
     180,   184,   191,   192,   196,   197,   202,   206,   209,   214,
     218,   221,   224,   228,   231,   234,   237,   240,   243,   246,
     249,   252,   258,   264,   271,   275,   278,   284,   287,   293,
     300,   301,   305,   306,   310,   311
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "NUM", "FNUM", "ID",
  "INT", "VOID", "FLOAT", "CHAR", "PRINT", "PRINTI", "PRINTC", "RETURN",
  "WHILE", "FOR", "LE", "GE", "EQ", "NE", "'<'", "'>'", "'+'", "'-'",
  "'*'", "'/'", "'('", "')'", "','", "'['", "']'", "';'", "'='", "'{'",
  "'}'", "$accept", "program", "function_list", "function", "params_opt",
  "params", "param", "type_spec", "stmt_list", "stmt", "decl", "assign",
  "assign_expr", "assign_expr_opt", "expr_opt", "expr", "while_stmt",
  "for_stmt", "print_stmt", "return_stmt", "func_call", "arg_list_opt",
  "arg_list", "block", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-110)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     275,   -19,  -110,  -110,  -110,  -110,   -15,   -11,   -10,    72,
       2,    17,    61,    93,  -110,    68,   275,  -110,  -110,  -110,
    -110,  -110,  -110,  -110,    63,     0,     0,     0,     0,     0,
       0,  -110,  -110,   -17,     0,  -110,    62,  -110,     0,    87,
    -110,  -110,    91,    16,    99,  -110,  -110,   191,    78,  -110,
     146,   114,   204,   216,   228,     0,   240,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,  -110,   252,    12,
    -110,    64,    82,    93,   113,  -110,    29,     0,  -110,    86,
    -110,    89,    97,   109,   161,  -110,   102,   102,    90,    90,
     102,   102,    -1,    -1,  -110,  -110,    88,     0,     0,     0,
      95,  -110,   115,   136,   112,  -110,     0,  -110,  -110,  -110,
    -110,    25,  -110,   176,   276,   125,   276,    88,    93,   128,
     127,   130,  -110,    57,   140,    87,  -110,  -110,   129,  -110,
    -110,  -110,     0,   117,  -110,   276,    88,  -110
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,    13,    16,    14,    15,     0,     0,     0,     0,
       0,     0,     0,     2,     4,     0,     3,    17,    19,    20,
      24,    25,    21,    22,     0,    60,     0,     0,     0,     0,
       0,    36,    37,    38,     0,    57,     0,    40,     0,    32,
       1,     5,     0,     0,     0,    18,    23,    62,     0,    61,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    58,     0,     0,
      33,     0,     0,     7,     0,    26,     0,     0,    59,     0,
      28,     0,     0,     0,     0,    41,    48,    49,    50,    51,
      46,    47,    42,    43,    44,    45,     0,     0,     0,    34,
       0,     8,     9,     0,     0,    63,     0,    54,    55,    56,
      39,     0,    52,     0,    30,     0,    35,     0,     0,    11,
       0,     0,    64,     0,     0,    32,     6,    10,     0,    27,
      29,    65,     0,     0,    12,    31,     0,    53
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -110,  -110,  -110,   147,  -110,    55,  -110,     1,    76,   -14,
    -110,  -110,  -110,    49,  -110,    -9,  -110,  -110,  -110,  -110,
       6,  -110,    98,  -109
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
       0,    12,    13,    14,   100,   101,   102,    44,    16,    17,
      18,    19,    70,    71,   115,    47,    20,    21,    22,    23,
      37,    48,    49,   112
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint8 yytable[] =
{
      36,    15,    45,    31,    32,    33,    24,    25,   126,    25,
      26,    28,    55,    27,    42,    29,    30,    50,    51,    52,
      53,    54,    24,    65,    66,    56,    34,   137,    38,    68,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    97,    73,    39,    98,    74,    84,    75,    86,    87,
      88,    89,    90,    91,    92,    93,    94,    95,    74,   122,
      75,    40,     1,     2,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    43,   103,    31,    32,    33,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,   113,   114,
     116,   131,    69,    67,    46,    99,    72,   121,    34,     2,
       3,     4,     5,    35,    76,    78,    57,    58,    73,    45,
      61,    62,    63,    64,    65,    66,   104,    24,   106,   103,
     107,   111,   117,   135,    63,    64,    65,    66,   108,    24,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
     109,   119,   120,   118,   136,    80,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,   125,   128,   129,   134,
      41,   130,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,   132,   127,   133,   105,    79,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,   123,     0,     0,
       0,   110,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,     0,     0,     0,     0,   124,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,     0,     0,    77,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
       0,    81,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,     0,    82,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,     0,    83,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,     0,    85,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,     0,    96,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,     0,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66
};

static const yytype_int16 yycheck[] =
{
       9,     0,    16,     3,     4,     5,     0,    26,   117,    26,
      29,    26,    29,    32,    13,    26,    26,    26,    27,    28,
      29,    30,    16,    24,    25,    34,    26,   136,    26,    38,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    29,    26,    26,    32,    29,    55,    31,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    29,    34,
      31,     0,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,     5,    73,     3,     4,     5,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    97,    98,
      99,    34,     5,    31,    31,    31,     5,   106,    26,     6,
       7,     8,     9,    31,     5,    27,    16,    17,    26,   123,
      20,    21,    22,    23,    24,    25,     3,   111,    32,   118,
      31,    33,    27,   132,    22,    23,    24,    25,    31,   123,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      31,     5,    30,    28,    27,    31,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    31,    29,    31,    30,
      13,    31,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    32,   118,   125,    77,    30,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,   111,    -1,    -1,
      -1,    30,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    -1,    -1,    -1,    -1,    30,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    -1,    -1,    28,
      16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      -1,    27,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    -1,    27,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    -1,    27,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    -1,    27,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    -1,    27,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    -1,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    36,    37,    38,    42,    43,    44,    45,    46,
      51,    52,    53,    54,    55,    26,    29,    32,    26,    26,
      26,     3,     4,     5,    26,    31,    50,    55,    26,    26,
       0,    38,    42,     5,    42,    44,    31,    50,    56,    57,
      50,    50,    50,    50,    50,    29,    50,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    31,    50,     5,
      47,    48,     5,    26,    29,    31,     5,    28,    27,    30,
      31,    27,    27,    27,    50,    27,    50,    50,    50,    50,
      50,    50,    50,    50,    50,    50,    27,    29,    32,    31,
      39,    40,    41,    42,     3,    57,    32,    31,    31,    31,
      30,    33,    58,    50,    50,    49,    50,    27,    28,     5,
      30,    50,    34,    43,    30,    31,    58,    40,    29,    31,
      31,    34,    32,    48,    30,    50,    27,    58
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    35,    36,    36,    37,    37,    38,    39,    39,    40,
      40,    41,    41,    42,    42,    42,    42,    43,    43,    44,
      44,    44,    44,    44,    44,    44,    45,    45,    46,    46,
      47,    47,    48,    48,    49,    49,    50,    50,    50,    50,
      50,    50,    50,    50,    50,    50,    50,    50,    50,    50,
      50,    50,    51,    52,    53,    53,    53,    54,    54,    55,
      56,    56,    57,    57,    58,    58
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     1,     2,     6,     0,     1,     1,
       3,     2,     4,     1,     1,     1,     1,     1,     2,     1,
       1,     1,     1,     2,     1,     1,     3,     6,     4,     7,
       3,     6,     0,     1,     0,     1,     1,     1,     1,     4,
       1,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     5,     9,     5,     5,     5,     2,     3,     4,
       0,     1,     1,     3,     2,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: function_list  */
#line 64 "parser.y"
                  {
        root = (yyvsp[0].node);
    }
#line 1254 "parser.tab.c"
    break;

  case 3: /* program: stmt_list  */
#line 67 "parser.y"
                {
        root = (yyvsp[0].node);
    }
#line 1262 "parser.tab.c"
    break;

  case 4: /* function_list: function  */
#line 73 "parser.y"
             {
        (yyval.node) = (yyvsp[0].node);
    }
#line 1270 "parser.tab.c"
    break;

  case 5: /* function_list: function_list function  */
#line 76 "parser.y"
                             {
        (yyval.node) = createFunctionList((yyvsp[-1].node), (yyvsp[0].node));
    }
#line 1278 "parser.tab.c"
    break;

  case 6: /* function: type_spec ID '(' params_opt ')' block  */
#line 82 "parser.y"
                                          {
        (yyval.node) = createFunction((yyvsp[-5].str), (yyvsp[-4].str), (yyvsp[-2].plist), (yyvsp[0].node));
        free((yyvsp[-5].str));
        free((yyvsp[-4].str));
    }
#line 1288 "parser.tab.c"
    break;

  case 7: /* params_opt: %empty  */
#line 90 "parser.y"
                {
        (yyval.plist) = NULL;
    }
#line 1296 "parser.tab.c"
    break;

  case 8: /* params_opt: params  */
#line 93 "parser.y"
             {
        (yyval.plist) = (yyvsp[0].plist);
    }
#line 1304 "parser.tab.c"
    break;

  case 9: /* params: param  */
#line 99 "parser.y"
          {
        (yyval.plist) = (yyvsp[0].plist);
    }
#line 1312 "parser.tab.c"
    break;

  case 10: /* params: param ',' params  */
#line 102 "parser.y"
                       {
        (yyvsp[-2].plist)->next = (yyvsp[0].plist);
        (yyval.plist) = (yyvsp[-2].plist);
    }
#line 1321 "parser.tab.c"
    break;

  case 11: /* param: type_spec ID  */
#line 109 "parser.y"
                 {
        (yyval.plist) = createParam((yyvsp[-1].str), (yyvsp[0].str), 0);
        free((yyvsp[-1].str));
        free((yyvsp[0].str));
    }
#line 1331 "parser.tab.c"
    break;

  case 12: /* param: type_spec ID '[' ']'  */
#line 114 "parser.y"
                           {
        (yyval.plist) = createParam((yyvsp[-3].str), (yyvsp[-2].str), 1);
        free((yyvsp[-3].str));
        free((yyvsp[-2].str));
    }
#line 1341 "parser.tab.c"
    break;

  case 13: /* type_spec: INT  */
#line 122 "parser.y"
        { (yyval.str) = strdup("int"); }
#line 1347 "parser.tab.c"
    break;

  case 14: /* type_spec: FLOAT  */
#line 123 "parser.y"
            { (yyval.str) = strdup("float"); }
#line 1353 "parser.tab.c"
    break;

  case 15: /* type_spec: CHAR  */
#line 124 "parser.y"
           { (yyval.str) = strdup("char"); }
#line 1359 "parser.tab.c"
    break;

  case 16: /* type_spec: VOID  */
#line 125 "parser.y"
           { (yyval.str) = strdup("void"); }
#line 1365 "parser.tab.c"
    break;

  case 17: /* stmt_list: stmt  */
#line 130 "parser.y"
         { 
        /* Base case: single statement */
        (yyval.node) = (yyvsp[0].node);  /* Pass the statement up as-is */
    }
#line 1374 "parser.tab.c"
    break;

  case 18: /* stmt_list: stmt_list stmt  */
#line 134 "parser.y"
                     { 
        /* Recursive case: list followed by another statement */
        (yyval.node) = createStmtList((yyvsp[-1].node), (yyvsp[0].node));  /* Build linked list of statements */
    }
#line 1383 "parser.tab.c"
    break;

  case 26: /* decl: type_spec ID ';'  */
#line 153 "parser.y"
                     {
        (yyval.node) = createTypedDecl((yyvsp[-2].str), (yyvsp[-1].str), 0, 0);
        free((yyvsp[-2].str));
        free((yyvsp[-1].str));
    }
#line 1393 "parser.tab.c"
    break;

  case 27: /* decl: type_spec ID '[' NUM ']' ';'  */
#line 158 "parser.y"
                                   {
        (yyval.node) = createTypedDecl((yyvsp[-5].str), (yyvsp[-4].str), 1, (yyvsp[-2].num));
        free((yyvsp[-5].str));
        free((yyvsp[-4].str));
    }
#line 1403 "parser.tab.c"
    break;

  case 28: /* assign: ID '=' expr ';'  */
#line 167 "parser.y"
                    { 
        /* Create assignment node with variable name and expression */
        (yyval.node) = createAssign((yyvsp[-3].str), (yyvsp[-1].node));  /* $1 = ID, $3 = expr */
        free((yyvsp[-3].str));                   /* Free the identifier string */
    }
#line 1413 "parser.tab.c"
    break;

  case 29: /* assign: ID '[' expr ']' '=' expr ';'  */
#line 172 "parser.y"
                                   {
        (yyval.node) = createArrayAssign((yyvsp[-6].str), (yyvsp[-4].node), (yyvsp[-1].node));
        free((yyvsp[-6].str));
    }
#line 1422 "parser.tab.c"
    break;

  case 30: /* assign_expr: ID '=' expr  */
#line 180 "parser.y"
                {
        (yyval.node) = createAssign((yyvsp[-2].str), (yyvsp[0].node));
        free((yyvsp[-2].str));
    }
#line 1431 "parser.tab.c"
    break;

  case 31: /* assign_expr: ID '[' expr ']' '=' expr  */
#line 184 "parser.y"
                               {
        (yyval.node) = createArrayAssign((yyvsp[-5].str), (yyvsp[-3].node), (yyvsp[0].node));
        free((yyvsp[-5].str));
    }
#line 1440 "parser.tab.c"
    break;

  case 32: /* assign_expr_opt: %empty  */
#line 191 "parser.y"
                { (yyval.node) = NULL; }
#line 1446 "parser.tab.c"
    break;

  case 33: /* assign_expr_opt: assign_expr  */
#line 192 "parser.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 1452 "parser.tab.c"
    break;

  case 34: /* expr_opt: %empty  */
#line 196 "parser.y"
                { (yyval.node) = NULL; }
#line 1458 "parser.tab.c"
    break;

  case 35: /* expr_opt: expr  */
#line 197 "parser.y"
           { (yyval.node) = (yyvsp[0].node); }
#line 1464 "parser.tab.c"
    break;

  case 36: /* expr: NUM  */
#line 202 "parser.y"
        { 
        /* Literal number */
        (yyval.node) = createNum((yyvsp[0].num));  /* Create leaf node with number value */
    }
#line 1473 "parser.tab.c"
    break;

  case 37: /* expr: FNUM  */
#line 206 "parser.y"
           {
        (yyval.node) = createFloat((yyvsp[0].fnum));
    }
#line 1481 "parser.tab.c"
    break;

  case 38: /* expr: ID  */
#line 209 "parser.y"
         { 
        /* Variable reference */
        (yyval.node) = createVar((yyvsp[0].str));  /* Create leaf node with variable name */
        free((yyvsp[0].str));            /* Free the identifier string */
    }
#line 1491 "parser.tab.c"
    break;

  case 39: /* expr: ID '[' expr ']'  */
#line 214 "parser.y"
                      {
        (yyval.node) = createArrayAccess((yyvsp[-3].str), (yyvsp[-1].node));
        free((yyvsp[-3].str));
    }
#line 1500 "parser.tab.c"
    break;

  case 40: /* expr: func_call  */
#line 218 "parser.y"
                {
        (yyval.node) = (yyvsp[0].node);
    }
#line 1508 "parser.tab.c"
    break;

  case 41: /* expr: '(' expr ')'  */
#line 221 "parser.y"
                   {
        (yyval.node) = (yyvsp[-1].node);
    }
#line 1516 "parser.tab.c"
    break;

  case 42: /* expr: expr '+' expr  */
#line 224 "parser.y"
                    { 
        /* Addition operation - builds binary tree */
        (yyval.node) = createBinOp('+', (yyvsp[-2].node), (yyvsp[0].node));  /* Left child, op, right child */
    }
#line 1525 "parser.tab.c"
    break;

  case 43: /* expr: expr '-' expr  */
#line 228 "parser.y"
                    {
        (yyval.node) = createBinOp('-', (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1533 "parser.tab.c"
    break;

  case 44: /* expr: expr '*' expr  */
#line 231 "parser.y"
                    {
        (yyval.node) = createBinOp('*', (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1541 "parser.tab.c"
    break;

  case 45: /* expr: expr '/' expr  */
#line 234 "parser.y"
                    {
        (yyval.node) = createBinOp('/', (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1549 "parser.tab.c"
    break;

  case 46: /* expr: expr '<' expr  */
#line 237 "parser.y"
                    {
        (yyval.node) = createCompare(CMP_LT, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1557 "parser.tab.c"
    break;

  case 47: /* expr: expr '>' expr  */
#line 240 "parser.y"
                    {
        (yyval.node) = createCompare(CMP_GT, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1565 "parser.tab.c"
    break;

  case 48: /* expr: expr LE expr  */
#line 243 "parser.y"
                   {
        (yyval.node) = createCompare(CMP_LE, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1573 "parser.tab.c"
    break;

  case 49: /* expr: expr GE expr  */
#line 246 "parser.y"
                   {
        (yyval.node) = createCompare(CMP_GE, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1581 "parser.tab.c"
    break;

  case 50: /* expr: expr EQ expr  */
#line 249 "parser.y"
                   {
        (yyval.node) = createCompare(CMP_EQ, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1589 "parser.tab.c"
    break;

  case 51: /* expr: expr NE expr  */
#line 252 "parser.y"
                   {
        (yyval.node) = createCompare(CMP_NE, (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1597 "parser.tab.c"
    break;

  case 52: /* while_stmt: WHILE '(' expr ')' block  */
#line 258 "parser.y"
                             {
        (yyval.node) = createWhile((yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1605 "parser.tab.c"
    break;

  case 53: /* for_stmt: FOR '(' assign_expr_opt ';' expr_opt ';' assign_expr_opt ')' block  */
#line 264 "parser.y"
                                                                       {
        (yyval.node) = createFor((yyvsp[-6].node), (yyvsp[-4].node), (yyvsp[-2].node), (yyvsp[0].node));
    }
#line 1613 "parser.tab.c"
    break;

  case 54: /* print_stmt: PRINT '(' expr ')' ';'  */
#line 271 "parser.y"
                           { 
        /* Create print node with expression to print */
        (yyval.node) = createPrint((yyvsp[-2].node));  /* $3 is the expression inside parens */
    }
#line 1622 "parser.tab.c"
    break;

  case 55: /* print_stmt: PRINTI '(' expr ')' ';'  */
#line 275 "parser.y"
                              {
        (yyval.node) = createPrintInline((yyvsp[-2].node));
    }
#line 1630 "parser.tab.c"
    break;

  case 56: /* print_stmt: PRINTC '(' expr ')' ';'  */
#line 278 "parser.y"
                              {
        (yyval.node) = createPrintChar((yyvsp[-2].node));
    }
#line 1638 "parser.tab.c"
    break;

  case 57: /* return_stmt: RETURN ';'  */
#line 284 "parser.y"
               {
        (yyval.node) = createReturn(NULL);
    }
#line 1646 "parser.tab.c"
    break;

  case 58: /* return_stmt: RETURN expr ';'  */
#line 287 "parser.y"
                      {
        (yyval.node) = createReturn((yyvsp[-1].node));
    }
#line 1654 "parser.tab.c"
    break;

  case 59: /* func_call: ID '(' arg_list_opt ')'  */
#line 293 "parser.y"
                            {
        (yyval.node) = createFunctionCall((yyvsp[-3].str), (yyvsp[-1].node));
        free((yyvsp[-3].str));
    }
#line 1663 "parser.tab.c"
    break;

  case 60: /* arg_list_opt: %empty  */
#line 300 "parser.y"
                { (yyval.node) = NULL; }
#line 1669 "parser.tab.c"
    break;

  case 61: /* arg_list_opt: arg_list  */
#line 301 "parser.y"
               { (yyval.node) = (yyvsp[0].node); }
#line 1675 "parser.tab.c"
    break;

  case 62: /* arg_list: expr  */
#line 305 "parser.y"
         { (yyval.node) = createArgList((yyvsp[0].node), NULL); }
#line 1681 "parser.tab.c"
    break;

  case 63: /* arg_list: expr ',' arg_list  */
#line 306 "parser.y"
                        { (yyval.node) = createArgList((yyvsp[-2].node), (yyvsp[0].node)); }
#line 1687 "parser.tab.c"
    break;

  case 64: /* block: '{' '}'  */
#line 310 "parser.y"
            { (yyval.node) = createBlock(NULL); }
#line 1693 "parser.tab.c"
    break;

  case 65: /* block: '{' stmt_list '}'  */
#line 311 "parser.y"
                        { (yyval.node) = createBlock((yyvsp[-1].node)); }
#line 1699 "parser.tab.c"
    break;


#line 1703 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 314 "parser.y"


/* ERROR HANDLING - Called by Bison when syntax error detected */
void yyerror(const char* s) {
    fprintf(stderr, "Syntax Error: %s\n", s);
}
