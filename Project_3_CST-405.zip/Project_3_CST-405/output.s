.data

.text

sumArray:
    # Prologue
    addi $sp, $sp, -8
    sw $fp, 0($sp)
    sw $ra, 4($sp)
    move $fp, $sp
    addi $sp, $sp, -4
    lw $t0, 8($fp)
    li $t1, 0
    sll $t1, $t1, 2
    add $t0, $t0, $t1
    lw $t2, 0($t0)
    lw $t1, 8($fp)
    li $t0, 1
    sll $t0, $t0, 2
    add $t1, $t1, $t0
    lw $t3, 0($t1)
    lw $t0, 12($fp)
    mul $t3, $t3, $t0
    add $t2, $t2, $t3
    lw $t3, 8($fp)
    li $t0, 2
    sll $t0, $t0, 2
    add $t3, $t3, $t0
    lw $t1, 0($t3)
    lw $t0, 12($fp)
    div $t1, $t0
    mflo $t1
    sub $t2, $t2, $t1
    sw $t2, -4($fp)
    lw $t2, -4($fp)
    move $v0, $t2
    j sumArray__end
sumArray__end:
    # Epilogue
    move $sp, $fp
    lw $fp, 0($sp)
    lw $ra, 4($sp)
    addi $sp, $sp, 8
    jr $ra

.globl main
main:
    # Prologue
    addi $sp, $sp, -8
    sw $fp, 0($sp)
    sw $ra, 4($sp)
    move $fp, $sp
    addi $sp, $sp, -20
    addi $t0, $fp, -12
    li $t1, 0
    sll $t1, $t1, 2
    add $t0, $t0, $t1
    li $t2, 10
    sw $t2, 0($t0)
    addi $t1, $fp, -12
    li $t0, 1
    sll $t0, $t0, 2
    add $t1, $t1, $t0
    li $t2, 6
    sw $t2, 0($t1)
    addi $t0, $fp, -12
    li $t1, 2
    sll $t1, $t1, 2
    add $t0, $t0, $t1
    li $t2, 4
    sw $t2, 0($t0)
    li $t1, 2
    addi $sp, $sp, -4
    sw $t1, 0($sp)
    addi $t1, $fp, -12
    addi $sp, $sp, -4
    sw $t1, 0($sp)
    jal sumArray
    addi $sp, $sp, 8
    move $t1, $v0
    sw $t1, -16($fp)
    lw $t1, -16($fp)
    # Print integer
    move $a0, $t1
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li.s $f2, 3.500000
    li.s $f3, 1.500000
    li.s $f4, 2.000000
    mul.s $f3, $f3, $f4
    add.s $f2, $f2, $f3
    s.s $f2, -20($fp)
    l.s $f2, -20($fp)
    # Print float
    mov.s $f12, $f2
    li $v0, 2
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
main__end:
    # Epilogue
    move $sp, $fp
    lw $fp, 0($sp)
    lw $ra, 4($sp)
    addi $sp, $sp, 8
    li $v0, 10
    syscall

