.data

.text

.globl main
main:
    # Prologue
    addi $sp, $sp, -8
    sw $fp, 0($sp)
    sw $ra, 4($sp)
    move $fp, $sp
    addi $sp, $sp, -8
    li $t0, 1
    sw $t0, -4($fp)
    li $t0, 0
    sw $t0, -8($fp)
main__while_start_0:
    lw $t0, -4($fp)
    li $t1, 5
    slt $t0, $t1, $t0
    xori $t0, $t0, 1
    beqz $t0, main__while_end_0
    lw $t0, -8($fp)
    lw $t1, -4($fp)
    add $t0, $t0, $t1
    sw $t0, -8($fp)
    lw $t0, -4($fp)
    li $t1, 1
    add $t0, $t0, $t1
    sw $t0, -4($fp)
    j main__while_start_0
main__while_end_0:
    lw $t0, -8($fp)
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0
    sw $t0, -8($fp)
    li $t0, 1
    sw $t0, -4($fp)
main__for_start_1:
    lw $t0, -4($fp)
    li $t1, 10
    slt $t0, $t1, $t0
    xori $t0, $t0, 1
    beqz $t0, main__for_end_1
    lw $t0, -8($fp)
    lw $t1, -4($fp)
    add $t0, $t0, $t1
    sw $t0, -8($fp)
    lw $t0, -4($fp)
    li $t1, 1
    add $t0, $t0, $t1
    sw $t0, -4($fp)
    j main__for_start_1
main__for_end_1:
    lw $t0, -8($fp)
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 1
    li $t1, 2
    li $t2, 3
    mul $t1, $t1, $t2
    add $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 1
    li $t1, 2
    add $t0, $t0, $t1
    li $t1, 3
    mul $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 1
    li $t1, 2
    add $t0, $t0, $t1
    li $t1, 4
    slt $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 1
    li $t1, 2
    li $t2, 4
    slt $t1, $t1, $t2
    add $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 20
    li $t1, 5
    sub $t0, $t0, $t1
    li $t1, 3
    sub $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 100
    li $t1, 10
    div $t0, $t1
    mflo $t0
    li $t1, 2
    mul $t0, $t0, $t1
    # Print integer
    move $a0, $t0
    li $v0, 1
    syscall
    # Print newline
    li $v0, 11
    li $a0, 10
    syscall
    li $t0, 0
    move $v0, $t0
    j main__end
main__end:
    # Epilogue
    move $sp, $fp
    lw $fp, 0($sp)
    lw $ra, 4($sp)
    addi $sp, $sp, 8
    li $v0, 10
    syscall

