int fillNumbers(int output[]) {
    output[0] = 100;
    output[1] = 200;
    output[2] = 300;
    return 3;
}

int readArray(int input[]) {
    int val;
    val = input[0];
    return val;
}

int sumFive(int a, int b, int c, int d, int e) {
    int result;
    result = a + b + c + d + e;
    return result;
}

int square(int n) {
    int result;
    result = n * n;
    return result;
}

int cube(int n) {
    int result;
    result = square(n) * n;
    return result;
}

int main() {
    int localArray[8];
    int resultArray[5];
    int globalA;
    int globalB;
    int globalC;
    int sharedArray[10];
    int a;
    int b;
    int c;
    int d;
    int e;
    int result;

    globalA = 1;
    globalB = 2;
    globalC = 3;
    sharedArray[0] = globalA + globalB + globalC;
    print(sharedArray[0]);

    print(111);
    localArray[0] = 10;
    localArray[1] = 20;
    localArray[2] = 30;
    localArray[3] = 40;
    localArray[4] = 50;

    print(localArray[0]);
    print(localArray[2]);
    print(localArray[4]);

    print(222);
    result = 1 + 2 + 3 + 4 + 5;
    print(result);

    print(333);
    a = 10;
    b = 20;
    c = 30;
    d = 40;
    e = 50;
    result = sumFive(a, b, c, d, e);
    print(result);

    print(444);
    fillNumbers(resultArray);
    print(resultArray[0]);
    print(resultArray[1]);
    print(resultArray[2]);

    print(555);
    result = readArray(localArray);
    print(result);

    print(666);
    a = square(5);
    print(a);
    b = cube(3);
    print(b);

    return 0;
}
