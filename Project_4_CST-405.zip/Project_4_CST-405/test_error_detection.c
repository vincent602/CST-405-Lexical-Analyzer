int sumFive(int a, int b, int c, int d, int e) {
    int result;
    result = a + b + c + d + e;
    return result;
}

int square(int n) {
    int result;
    result = n * n;
    return result;
}

int square(int n) {
    return n * n;
}

int errorChecks() {
    int x;
    int x;
    int a[3];
    int empty[0];

    x = 10 / 0;
    x = a;
    x = a[5];
    x = x[0];
    x = sumFive(1, 2);

    return x;
}

int main() {
    int arr[3];
    int result;

    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;

    result = sumFive(1, 2, 3, 4, 5);
    print(result);

    result = square(5);
    print(result);

    return 0;
}
